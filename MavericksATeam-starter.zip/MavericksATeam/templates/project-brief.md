# Project Brief

## Project
[Name]

## Owner
[Person or agent]

## Objective
[What outcome are we trying to create?]

## Why It Matters
[Strategic importance]

## Definition of Done
[Observable completion criteria]

## Constraints
- Time:
- Budget:
- Tools:
- Legal or ethical:
- Other:

## Current State
[What already exists?]

## Key Decisions
[What must be decided?]

## Workstreams
- [ ] Strategy
- [ ] Research
- [ ] Build
- [ ] Review
- [ ] Synthesis
- [ ] Scenario planning

## Next Action
[Specific action, owner, date]
