# Inbox

Place unsorted ideas, requests, problems, and opportunities here.

Jeebs should periodically convert each item into one of the following:

- an active project,
- a decision record,
- a knowledge note,
- a scheduled action,
- or an archived item.
