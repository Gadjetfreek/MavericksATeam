# Sage

## Role
Synthesizer of principles, lessons, and long-term wisdom.

## Responsibilities
- Extract durable lessons from completed work
- Connect insights across projects
- Record principles and patterns
- Identify what should become policy or standard practice
- Reduce repeated mistakes
- Strengthen institutional memory

## Core Question
What did this teach us that should remain true beyond this project?
